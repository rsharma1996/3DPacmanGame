﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GhostScript : MonoBehaviour {
    public Color c;
    public GameObject target; //player
    public NavMeshAgent agent; //ghosts
  //  public Text score;
    public SaveScore myscore; //calling savescore to display leaderboard if the player collides with ghost
    public AudioClip bomb; //my audioclip when the player collides with the ghost
    private AudioSource audioSource;
    public  bool isAway;
    int timeLeft = 15;
    bool timeStart = false;
    public int multiplyBy = 5;
   // public PelletScript keyCount;
   
    // Use this for initialization
    void Start () {
        GetComponent<Renderer>().material.color = c;
        isAway = true;
        agent = GetComponent<NavMeshAgent>();
        audioSource = GetComponent<AudioSource>();
        // audioSource = GetComponent<AudioSource>();
        if (target == null)
            target = GameObject.FindGameObjectWithTag("Player");
        

        }
    

    // Update is called once per frame
    //if isaway then the ghosts they attack, else the pacman attacks them after eating the fruit pellet
    void Update () {

        if (isAway)
            {
            agent.destination = target.transform.position;
            }
        else
            {
            RunFrom();
            }
        //agent.destination = target.transform.position;
        if (!isAway)
            {
            if (!timeStart)
                {
                timeStart = true;
                StartCoroutine("LoseTime");
                }
            if (timeLeft == 0)
                {
                isAway = true;
                GetComponent<Renderer>().material.color = c;
                }

            }
		
	}
    //collision
    private void OnCollisionEnter(Collision other)
        {
        if (other.gameObject.tag == "Player")
            {

            if (isAway)
                {
                Debug.Log("something Test");

                myscore.alive = false; //calls the stuff from savescore
                Time.timeScale = 0;
                myscore.inputText.ActivateInputField();
                myscore.entername.SetActive(true);
                myscore.secScore.SetActive(true);

                audioSource.clip = bomb; //play audio upon collision player with ghost
                audioSource.Play();
                }
            else
                {
                Destroy(agent.gameObject);
                }
                
           
            }
        
        }
    public void RunFrom()
        {

        //temporarily point the object to look away from the player
        agent.transform.rotation = Quaternion.LookRotation(agent.transform.position - target.transform.position);

        //Then we'll get the position on that rotation that's multiplyBy down the path (you could set a Random.range
        // for this if you want variable results) and store it in a new Vector3 called runTo
        Vector3 runTo = transform.position + transform.forward * multiplyBy;
        //Debug.Log("runTo = " + runTo);

        //So now we've got a Vector3 to run to and we can transfer that to a location on the NavMesh with samplePosition.

        NavMeshHit hit;    // stores the output in a variable called hit

        // 5 is the distance to check, assumes you use default for the NavMesh Layer name
        NavMesh.SamplePosition(runTo, out hit, 5, 1 << NavMesh.GetNavMeshLayerFromName("Default"));
        

        // And get it to head towards the found NavMesh position
        agent.SetDestination(hit.position);
        }

    //decrease the timer
    //onfinishing up all 15 secs
    IEnumerator LoseTime()
        {
        while (true)
            {
            yield return new WaitForSeconds(1);
            timeLeft--;
            }
        }

    }
