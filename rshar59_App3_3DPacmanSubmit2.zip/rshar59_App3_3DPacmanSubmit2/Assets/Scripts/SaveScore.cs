﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SaveScore : MonoBehaviour {
   // public Text obj;
    public InputField inputText;
    public Text finalScore;
  //  public GameObject pause;
    public GameObject entername;
    public GameObject secScore;
    public bool alive = true;
   // public GameObject player;
    
	// Use this for initialization
	void Start () {
        inputText.DeactivateInputField();
        inputText.characterLimit = 3;
        entername.SetActive(false);
        secScore.SetActive(false);
       // pause.SetActive(false);
        Time.timeScale = 1;

        }
	
	// Update is called once per frame
	void Update () {
       
        finalScore.text = PlayerPrefs.GetString("PelletScore");

        if (PlayerPrefs.GetString("PelletScore") == "Score: 5400" ||!alive)

            {
            Time.timeScale = 0;
            inputText.ActivateInputField();
            entername.SetActive(true);
            secScore.SetActive(true);
            }


        }

  //checking whose score is higher
    private bool highScore(int score1, int score2)
        {
        //newscore >oldscore
        if (score1 > score2)
            {
            return true;
            }
        return false;


        }
    
public void leaderScorers()
        {
        
        string[] scores = finalScore.text.Split(' '); //splitting scores
            //highest scorer is displayed on top then the lower
       
        if (!(PlayerPrefs.HasKey("player0")))
            {
            PlayerPrefs.SetString("player0", inputText.text);
            PlayerPrefs.SetString("score0", scores[1]);
            }
        else if (!(PlayerPrefs.HasKey("player1")))
            {
            string score0 = PlayerPrefs.GetString("score0"); //get the score for the first player

            if (highScore(int.Parse(scores[1]), int.Parse(score0)))
                {
                PlayerPrefs.SetString("player1", PlayerPrefs.GetString("player0"));
                PlayerPrefs.SetString("score1", PlayerPrefs.GetString("score0"));
                PlayerPrefs.SetString("player0", inputText.text);
                PlayerPrefs.SetString("score0", scores[1]);
                }
            else
                {
                PlayerPrefs.SetString("player1", inputText.text);
                PlayerPrefs.SetString("score1", scores[1]);
                }
            }
        else if (!(PlayerPrefs.HasKey("player2")))//If there is no third score.
            {
            string score0 = PlayerPrefs.GetString("score0");
            string score1 = PlayerPrefs.GetString("score1");

            if (highScore(int.Parse(scores[1]), int.Parse(score0)))
                {
                PlayerPrefs.SetString("player2", PlayerPrefs.GetString("player1"));
                PlayerPrefs.SetString("score2", PlayerPrefs.GetString("score1"));
                PlayerPrefs.SetString("player1", PlayerPrefs.GetString("player0"));
                PlayerPrefs.SetString("score1", PlayerPrefs.GetString("score0"));
                PlayerPrefs.SetString("player0", inputText.text);
                PlayerPrefs.SetString("score0", scores[1]);
                }
            else if (highScore(int.Parse(scores[1]), int.Parse(score1)))
                {
                PlayerPrefs.SetString("player2", PlayerPrefs.GetString("player1"));
                PlayerPrefs.SetString("score2", PlayerPrefs.GetString("score1"));
                PlayerPrefs.SetString("player1", inputText.text);
                PlayerPrefs.SetString("score1", scores[1]);
                }
            else
                {
                PlayerPrefs.SetString("player2", inputText.text);
                PlayerPrefs.SetString("score2", scores[1]);
                }
            }
        else
            {
            string score0 = PlayerPrefs.GetString("score0");
            string score1 = PlayerPrefs.GetString("score1");
            string score2 = PlayerPrefs.GetString("score2");

            if (highScore( int.Parse(scores[1]), int.Parse(score0)))
                {
                PlayerPrefs.SetString("player2", PlayerPrefs.GetString("player1"));
                PlayerPrefs.SetString("score2", PlayerPrefs.GetString("score1"));
                PlayerPrefs.SetString("player1", PlayerPrefs.GetString("player0"));
                PlayerPrefs.SetString("score1", PlayerPrefs.GetString("score0"));
                PlayerPrefs.SetString("player0", inputText.text);
                PlayerPrefs.SetString("score0", scores[1]);
                }
            else if (highScore(int.Parse(scores[1]), int.Parse(score1)))
                {
                PlayerPrefs.SetString("player2", PlayerPrefs.GetString("player1"));
                PlayerPrefs.SetString("score2", PlayerPrefs.GetString("score1"));
                PlayerPrefs.SetString("player1", inputText.text);
                PlayerPrefs.SetString("score1", scores[1]);
                }
            else if (highScore(int.Parse(scores[1]), int.Parse(score2)))
                {
                PlayerPrefs.SetString("player2", inputText.text);
                PlayerPrefs.SetString("score2", scores[1]);
                }
            }
        Time.timeScale = 1;
        SceneManager.LoadScene("LeaderBoard"); //this is for loading the leaderboard scene
        
        }


    }
