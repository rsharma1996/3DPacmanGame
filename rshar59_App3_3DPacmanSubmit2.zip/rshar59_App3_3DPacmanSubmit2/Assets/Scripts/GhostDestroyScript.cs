﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//This script is for detsroying the ghosts and the main power pellet
//Ghosts are destroyed when the user collides with the fruit1 cube i.e. different from other general power pellets
public class GhostDestroyScript : MonoBehaviour {
    public GhostScript g1;
    public GhostScript g2;
    public GhostScript g3;
    public GameObject ghost1;
    public GameObject ghost2;
    public GameObject ghost3;
    public GameObject myfruit;
    public Color mycolor;


    private void OnCollisionEnter(Collision other)
        {
        if (other.gameObject.tag == "Player")
            {
            //Destroy(ghost1);
            //Destroy(ghost2);
            //Destroy(ghost3);
            //changing colors
            ghost1.GetComponent<Renderer>().material.color = mycolor;
            ghost2.GetComponent<Renderer>().material.color = mycolor;
            ghost3.GetComponent<Renderer>().material.color = mycolor;
            g1.isAway = false;
            g2.isAway = false;
            g3.isAway = false;

            Destroy(myfruit);
            }


        }
}
