﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PelletScript : MonoBehaviour {
    public static int pelletCount = 0;
   // public GameObject pellet;
    //public GameObject player;
    private int scoretry;
   // public static bool destroyPacman = false;
   // public Text obj;
    

	// Use this for initialization
	void Start () {
        PlayerPrefs.SetString("PelletScore", "Score: ");
        pelletCount = 0;
        }
	
	// Update is called once per frame
	void Update () {
       // pelletCount++;
        // obj.text = PlayerPrefs.GetString("PelletScore");
        }
    /*public void OnCollisionEnter(Collision other)
        {
        


        }
    public void OnTriggerEnter(Collider other)
        {
        if (other.gameObject.tag == "Player")
            {
            // Destroying pellets after player collides with them 
            Destroy(pellet);
            pelletCount++;
            //scores are displayed as a multiple of 100
            PlayerPrefs.SetString("PelletScore", "Score: " + pelletCount * 100);
            }
        }
        */
        //for detsroying the pellets
        //ball script: onTriggerEnter
        //triggers on pellet
    public void OnDestroy()
        {
        
            
            // Destroying pellets after player collides with them 
           
            pelletCount++;
            //scores are displayed as a multiple of 100
            PlayerPrefs.SetString("PelletScore", "Score: " + pelletCount * 100);

            
}
        }
