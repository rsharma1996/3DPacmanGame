﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IntermediateMenuScript : MonoBehaviour {

    public GameObject pause;
    // Use this for initialization
    void Start () {
        pause.SetActive(false);
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.Escape))
            {
            if (!pause.activeInHierarchy) //pause.active is obsolete now
                {

                PauseGame();
                }
            else
                {
                RestartGame();
                }

            }
        }
    //Restart the game
    private void RestartGame()
        {
        Time.timeScale = 1;
        pause.SetActive(false);

        }
    //this is for pausing the game
    private void PauseGame()
        {
        Time.timeScale = 0;
        pause.SetActive(true);

        }
    }
