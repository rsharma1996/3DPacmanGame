﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenuScript : MonoBehaviour {
    //public Text obj;

    public void StartScene(string name)
        {
        Time.timeScale = 1;
        SceneManager.LoadScene(name);
        }
    public void EndGame()
        {
        Application.Quit();
       // EditorApplication.isPlaying = false; 
        // Use this if not using Build

        }
  
	
    
}
