﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LeaderBoardScript : MonoBehaviour {
    public Text player0;
    public Text player1;
    public Text player2;
    public Text score0;
    public Text score1;
    public Text score2;
    //ParticleSystem play;
    // Use this for initialization
    void Start()

        {
       // play = GetComponent<ParticleSystem>();
         
        if (PlayerPrefs.HasKey("player0"))
            {
            player0.text = PlayerPrefs.GetString("player0");
            score0.text = PlayerPrefs.GetString("score0");
            }
        if (PlayerPrefs.HasKey("player1"))
            {
            player1.text = PlayerPrefs.GetString("player1");
            score1.text = PlayerPrefs.GetString("score1");
            }
        if (PlayerPrefs.HasKey("player2"))
            {
            player2.text = PlayerPrefs.GetString("player2");
            score2.text = PlayerPrefs.GetString("score2");
            }
        }

    void Update()
        {
        //play.Play();

        }
    // Update is called once per frame

    }

